plain = 'ABCD'
p = 13
q = 29
e = 5
N = p * q
cipher = []

for i in plain:
    tmp_c = pow(ord(i), e, N)
    cipher.append(tmp_c)

print(cipher)
