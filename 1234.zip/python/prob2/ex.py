import sys
sys.setrecursionlimit(10000)

with open('input.txt', 'r') as f:
    for i in range(6):
        exec(f.readline())

def egcd(a, b):
    if a == 0:
        return (b, 0, 1)
    else:
        g, y, x = egcd(b % a, a)
        return (g, x - (b // a) * y, y)

def modinv(a, m):
    g, x, y = egcd(a, m)
    if g != 1:
        raise Exception('modular inverse does not exist')
    else:
        return x % m

def crt(tmp_n, tmp_m, n, m):
    tmp0, tmp1, tmp2 = egcd(n,m)
    tmp3 = egcd(m,n)[1]
    if tmp0 != 1:
        exit()
    tmp = (tmp1 * n * tmp_m + tmp3 * m * tmp_n) % (n * m)
    if tmp % n != tmp_n or tmp % m != tmp_m:
        exit()
    return tmp

def find_invpow(x,n):
    high = 1
    while high ** n <= x:
        high *= 2
    low = high // 2
    while low < high:
        mid = (low + high) // 2
        if low < mid and mid**n < x:
            low = mid
        elif high > mid and mid**n > x:
            high = mid
        else:
            return mid
    return mid + 1

tmp_result = crt(C1, C2, N1, N2)

tmp_result = crt(tmp_result, C3, N1 * N2, N3)

result = find_invpow(tmp_result, 3)

if pow(result,3,N1) == C1 and pow(result,3,N2) == C2 and pow(result,3,N3) == C3:
    print("M = {}".format(result))
