import os
import sys
from datetime import datetime
import binascii

if len(sys.argv) != 2:
    print('Incorrect argv length')
    exit()

def get_info(f, path):
    stream = os.popen('ls -al ' + path)
    output = stream.read()
    res1 = output.split('\n')[1:-1]
    for i in res1:
        tmp = i.split()
        name = ''

        for j in tmp[8:]:
            name += j + ' '
        
        if name == '. ' or name == '.. ':
            continue
        
        if 'd' in tmp[0]:
            if path[-1] != '/':
                get_info(f, '{}/{}/'.format(path, name[:-1]))
            else:
                get_info(f, '{}{}/'.format(path, name[:-1]))
        else:
            cmd = 'sha1sum '
            if path[-1] != '/':
                cmd += path + '/'+ name
            else:
                cmd += path + name
            stream = os.popen(cmd)
            output = stream.read().split()[0]

            string = '{:<57} {} {:>7} {:>7} {:>7} {} {} {:<5} {}\n'.format(cmd[8:], tmp[0], tmp[2], tmp[3], tmp[4], tmp[5], tmp[6].zfill(2), tmp[7],  output)
            f.write(string)

            
now = datetime.now()
date = now.strftime("%Y%m%d_%H%M%S")

path = sys.argv[1]
path_name = binascii.hexlify(path.encode())
filename = '{}_{}.log'.format(date, path_name.decode())
print(filename)

f = open(filename, 'w') 
f.write(path + '\n')

get_info(f, path)


