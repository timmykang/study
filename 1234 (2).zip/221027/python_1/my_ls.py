import os
import sys
from datetime import datetime

def month_string_to_number(string):
    m = {
        'jan': 1,
        'feb': 2,
        'mar': 3,
        'apr':4,
         'may':5,
         'jun':6,
         'jul':7,
         'aug':8,
         'sep':9,
         'oct':10,
         'nov':11,
         'dec':12
        }
    s = string.strip()[:3].lower()

    try:
        out = m[s]
        return out
    except:
        raise ValueError('Not a month')

def print_sorted_list(tmp, res):
    sorted_dict = sorted(tmp.items(), key = lambda item: item[1])
    if sys.argv[3] == 'asc':
        for i, _ in sorted_dict:
            print(res[i])
    elif sys.argv[3] == 'desc':
        for i, _ in sorted_dict[::-1]:
            print(res[i])
    else:
        print('Invalid argument!')
        exit()

if len(sys.argv) != 4:
    print('Incorrect argv length')
    exit()

stream = os.popen('ls -al ' + sys.argv[1])
output = stream.read()
res1 = output.split('\n')[1:]

res = []
res_sort = [{}, {}, {}, {}, {}, {}]
for i in range(len(res1) - 1):
    tmp = res1[i].split()
    tmp1 = [tmp[0], tmp[2], tmp[3], int(tmp[4])]
    
    tmp_date = str(month_string_to_number(tmp[5])).zfill(2) + '-' + tmp[6].zfill(2)
    if ':' in tmp[7]:
        tmp_date = str(datetime.today().year) + '-' + tmp_date + ' ' + tmp[7]
    else:
        tmp_date = tmp[7] + '-' + tmp_date + ' 00:00'
    
    tmp1.append(tmp_date)

    tmp_str = ''
    for j in tmp[8:]:
        tmp_str += j + ' '
    tmp1.append(tmp_str)
    
    for j in range(len(tmp1)):
        res_sort[j][i] = tmp1[j]
    
    res.append('{} {:>7} {:>7} {:>7} {} {}'.format(tmp1[0], tmp1[1], tmp1[2], tmp1[3], tmp1[4], tmp1[5]))

if sys.argv[2] == 'permission':
    print_sorted_list(res_sort[0], res)
elif sys.argv[2] == 'ownership':
    print_sorted_list(res_sort[1], res)
elif sys.argv[2] == 'group':
    print_sorted_list(res_sort[2], res)
elif sys.argv[2] == 'size':
    print_sorted_list(res_sort[3], res)
elif sys.argv[2] == 'date':
    print_sorted_list(res_sort[4], res)
elif sys.argv[2] == 'filename':
    print_sorted_list(res_sort[5], res)
else:
    print('Invalid argument')
    exit()


